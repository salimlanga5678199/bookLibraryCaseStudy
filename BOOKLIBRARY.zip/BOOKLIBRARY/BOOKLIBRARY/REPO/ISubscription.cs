﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOKLIBRARY.REPO
{
    public interface ISubscription
    {
        public Task<List<Subscribe>> getAllSubscribe();
        public Task<IEnumerable<BOOK>> GetSubscribeBookByIdAsync(string Id);
        public Task<int> AddSubScriptionAsync(SubscribePost sub);
    }
}
