﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOKLIBRARY.REPO
{
    public class bookService : IbookService
    {
        private readonly applicationDbContext _dbContext;

        public bookService(applicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<BOOK>> getAllBook()
        {
            return await _dbContext.books
                .FromSqlRaw<BOOK>("GetBookData")
                .ToListAsync();
        }
    }
}
