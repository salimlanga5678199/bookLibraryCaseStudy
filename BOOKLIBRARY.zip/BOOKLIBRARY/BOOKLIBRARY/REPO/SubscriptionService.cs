﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace BOOKLIBRARY.REPO
{
    public class SubscriptionService : ISubscription
    {
        private readonly applicationDbContext _dbContext;

        public SubscriptionService(applicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<Subscribe>> getAllSubscribe()
        {
            
            return await _dbContext.sub
               .FromSqlRaw<Subscribe>("get_subscription_data")
               .ToListAsync();
        }
        public async Task<IEnumerable<BOOK>> GetSubscribeBookByIdAsync(string Bookid)
        {
            var BookDetails = await Task.Run(() => _dbContext.books
                                   .FromSqlRaw($"checkBookAvailable @Bookid = '{Bookid}'").ToList());
            return BookDetails;
        }

        public async Task<int> AddSubScriptionAsync(SubscribePost sub)
        {
            var result = await _dbContext.Database.ExecuteSqlRawAsync($"exec InsertSubscription @SUBSCRIBER_NAME= '{sub.SUBSCRIBER_NAME}',@DATE_SUBSCRIBED='{sub.DATE_SUBSCRIBED}',@BOOK_ID= '{sub.BOOK_ID}'");
            return result;
        }


    }
}
