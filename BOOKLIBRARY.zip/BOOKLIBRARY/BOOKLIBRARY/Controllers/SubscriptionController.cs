﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BOOKLIBRARY.REPO;
using NPOI.SS.Formula.Functions;
using System.Net.Http;
using System.Net;
using Microsoft.AspNetCore.Http;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BOOKLIBRARY.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubscriptionController : ControllerBase
    {
        private readonly ISubscription SubscriptionService;
        public SubscriptionController(applicationDbContext book, ISubscription SubscriptionService)
        {
          
            this.SubscriptionService = SubscriptionService;
        }
        // GET: api/<SubscriptionController>
        [HttpGet]
        public async Task<List<Subscribe>> Get()
        {
            try
            {
                return await SubscriptionService.getAllSubscribe();
            }
            catch
            {
                throw;
            }
        }

        // POST api/<SubscriptionController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] SubscribePost sub)
        {
            try
            {
                var response = await SubscriptionService.GetSubscribeBookByIdAsync(sub.BOOK_ID);

                if (response == null)
                {
                    
                 return new ObjectResult(sub) { StatusCode = StatusCodes.Status422UnprocessableEntity };
                }
                else
                {
                    var response2 = await SubscriptionService.AddSubScriptionAsync(sub);

                    return new ObjectResult(sub) { StatusCode = StatusCodes.Status201Created };
                }
               
            }
            catch
            {
                throw;
            }
          

        }

      
    }
}
