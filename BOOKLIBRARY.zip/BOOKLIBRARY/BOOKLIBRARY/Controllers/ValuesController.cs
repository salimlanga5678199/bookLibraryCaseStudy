﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BOOKLIBRARY.REPO;
namespace BOOKLIBRARY.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private applicationDbContext context;
        private readonly IbookService bookService;
        public ValuesController(applicationDbContext book,IbookService bookService)
        {
            this.context = book;
            this.bookService = bookService;
        }

        [HttpGet] 
        public async Task<List<BOOK>> Get()
        {
            try
            {
                return await bookService.getAllBook();
            }
            catch
            {
                throw;
            }
        }
    }

}
