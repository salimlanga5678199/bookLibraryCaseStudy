﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOKLIBRARY
{
    public class applicationDbContext : DbContext
    {

        public applicationDbContext(DbContextOptions<applicationDbContext> options) : base(options)
        { }
        public DbSet<BOOK> books { get; set; }
        public DbSet<Subscribe> sub { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

        }
    }
}
