﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BOOKLIBRARY
{
    public class BOOK
    {   [Key]
        public string BOOK_ID { get; set; }
        public string BOOK_NAME { get; set; }
        public string AUTHOR { get; set; }
        public int AVAILABLE_COPIES { get; set; }
        public int TOTAL_COPIES { get; set; }
    }
    public class Subscribe
    {   [Key]
        public string SUBSCRIBER_NAME { get; set; }
        public string BOOK_ID { get; set; }
        public DateTime DATE_SUBSCRIBED { get; set; }
        public DateTime DATE_RETURNED { get; set; }
    }
    public class SubscribePost
    {
        public string SUBSCRIBER_NAME { get; set; }
        public string BOOK_ID { get; set; }
        public DateTime DATE_SUBSCRIBED { get; set; }
    }
}
